#include "Ente.h"

GerenciadorGrafico* Ente::graphics = GerenciadorGrafico::getInstance();

Ente::Ente() {}

Ente::~Ente() {}